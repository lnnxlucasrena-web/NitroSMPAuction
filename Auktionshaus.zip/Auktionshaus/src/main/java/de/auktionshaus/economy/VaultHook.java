package de.auktionshaus.economy;

import de.auktionshaus.Main;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

public class VaultHook {
    private Economy economy;
    public VaultHook(Main plugin) {
        if (Bukkit.getPluginManager().getPlugin("Vault") != null) {
            RegisteredServiceProvider<Economy> rsp = Bukkit.getServicesManager().getRegistration(Economy.class);
            if (rsp != null) economy = rsp.getProvider();
        }
    }
    public boolean isEnabled() { return economy != null; }
    public double getBalance(Player player) { return economy.getBalance(player); }
    public boolean withdraw(Player player, double amount) { return economy.withdrawPlayer(player, amount).transactionSuccess(); }
    public boolean deposit(Player player, double amount) { return economy.depositPlayer(player, amount).transactionSuccess(); }
}
