package de.auktionshaus.config;

import de.auktionshaus.Main;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import java.io.IOException;

public class FileManager {
    private final Main plugin;
    private FileConfiguration config, messages, auctions;
    private File configFile, messagesFile, auctionsFile;

    public FileManager(Main plugin) {
        this.plugin = plugin;
        setup();
    }

    public void setup() {
        configFile = new File(plugin.getDataFolder(), "config.yml");
        messagesFile = new File(plugin.getDataFolder(), "messages.yml");
        auctionsFile = new File(plugin.getDataFolder() + "/data", "auctions.yml");
        if (!configFile.exists()) plugin.saveResource("config.yml", false);
        if (!messagesFile.exists()) plugin.saveResource("messages.yml", false);
        if (!auctionsFile.exists()) {
            auctionsFile.getParentFile().mkdirs();
            plugin.saveResource("data/auctions.yml", false);
        }
        config = YamlConfiguration.loadConfiguration(configFile);
        messages = YamlConfiguration.loadConfiguration(messagesFile);
        auctions = YamlConfiguration.loadConfiguration(auctionsFile);
    }

    public FileConfiguration getConfig() { return config; }
    public FileConfiguration getMessages() { return messages; }
    public FileConfiguration getAuctions() { return auctions; }

    public void saveAuctions() {
        try { auctions.save(auctionsFile); } catch (IOException ignored) {}
    }
    public void reloadAll() {
        config = YamlConfiguration.loadConfiguration(configFile);
        messages = YamlConfiguration.loadConfiguration(messagesFile);
        auctions = YamlConfiguration.loadConfiguration(auctionsFile);
    }
}
