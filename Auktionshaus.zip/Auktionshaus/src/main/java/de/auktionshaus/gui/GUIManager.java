package de.auktionshaus.gui;

import de.auktionshaus.Main;
import de.auktionshaus.auction.AuctionItem;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import java.util.*;

public class GUIManager implements Listener {
    private final Main plugin;
    private static final int PAGE_SIZE = 36;
    private java.sql.Connection sqlConnection;
    // Map für Bestätigungs-GUI (Spieler -> AuctionItem)
    private final Map<UUID, AuctionItem> confirmMap = new HashMap<>();
    public GUIManager(Main plugin) {
        this.plugin = plugin;
    }
    private void setupDatabase() {
        try {
            Class.forName("org.sqlite.JDBC");
            java.io.File dbFile = new java.io.File("plugins/NitroSMPAuction/auctions.db");
            dbFile.getParentFile().mkdirs();
            sqlConnection = java.sql.DriverManager.getConnection("jdbc:sqlite:" + dbFile.getAbsolutePath());
            java.sql.Statement st = sqlConnection.createStatement();
            st.executeUpdate("CREATE TABLE IF NOT EXISTS auctions (id TEXT PRIMARY KEY, seller TEXT, sellerName TEXT, item BLOB, price REAL, endTime INTEGER, amount INTEGER)");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void openMainMenu(Player player, int page) {
        if (sqlConnection == null) setupDatabase();
        // Statt eigene DB: Zeige die aktuellen Auktionen aus AuctionManager
        List<AuctionItem> all = plugin.getAuctionManager().getFilteredSortedAuctions();
        int maxPage = Math.max(1, (int) Math.ceil(all.size() / (double) PAGE_SIZE));
        if (page < 1) page = 1;
        if (page > maxPage) page = maxPage;
        plugin.getPlayerCache().setPage(player.getUniqueId(), page);
        String title = "§2§lAuktionshaus §7| §aSeite " + page + "§7/§a" + maxPage;
        Inventory inv = Bukkit.createInventory(null, 54, title);
        int start = (page - 1) * PAGE_SIZE;
        int end = Math.min(start + PAGE_SIZE, all.size());
        for (int i = start; i < end; i++) {
            AuctionItem ai = all.get(i);
            String itemName = ai.getItem().getItemMeta() != null && ai.getItem().getItemMeta().hasDisplayName()
                ? ai.getItem().getItemMeta().getDisplayName()
                : ai.getItem().getType().name().replace('_', ' ');
            String priceStr = String.format("%,.2f", ai.getPrice()).replace(',', '.').replace('.', ',') + " $";
            long millisLeft = ai.getEndTime() - System.currentTimeMillis();
            String timeLeft;
            if (millisLeft > 0) {
                long seconds = millisLeft / 1000;
                long hours = seconds / 3600;
                long minutes = (seconds % 3600) / 60;
                if (hours > 0) {
                    timeLeft = hours + "h " + minutes + "m";
                } else {
                    timeLeft = minutes + "m";
                }
            } else {
                timeLeft = "abgelaufen";
            }
            List<String> lore = List.of(
                "§bPreis: §6" + priceStr,
                "§cVerkäufer: §f" + ai.getSellerName(),
                "§aEndet in: §e" + timeLeft,
                "§eAuktions-ID: §7" + ai.getAuctionId().toString().substring(0, 8)
            );
            ItemStack item = ai.getItem().clone();
            // Name und Lore setzen, ohne ItemBuilder (um Meta zu erhalten)
            if (item.getItemMeta() != null) {
                var meta = item.getItemMeta();
                meta.setDisplayName(itemName);
                meta.setLore(lore);
                item.setItemMeta(meta);
            }
            inv.setItem(i - start, item);
        }
        // Navigation & Symbole (jetzt farbig und modern)
        ItemStack prev = new ItemStack(Material.ARROW);
        ItemMeta prevMeta = prev.getItemMeta();
        prevMeta.setDisplayName("§bVorherige Seite");
        prevMeta.setLore(Arrays.asList("§7Klicke, um zurückzublättern"));
        prev.setItemMeta(prevMeta);
        inv.setItem(45, prev);

        ItemStack filter = new ItemStack(Material.NETHER_STAR);
        ItemMeta filterMeta = filter.getItemMeta();
        filterMeta.setDisplayName("§aFilter & Sortierung");
        filterMeta.setLore(Arrays.asList("§7Klicke zum Filtern/Sortieren!"));
        filter.setItemMeta(filterMeta);
        inv.setItem(49, filter);

        ItemStack next = new ItemStack(Material.ARROW);
        ItemMeta nextMeta = next.getItemMeta();
        nextMeta.setDisplayName("§bNächste Seite");
        nextMeta.setLore(Arrays.asList("§7Klicke, um weiterzublättern"));
        next.setItemMeta(nextMeta);
        inv.setItem(53, next);

        player.openInventory(inv);
    }
    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player player)) return;
        if (e.getView().getTitle().contains("Auktionshaus")) {
            e.setCancelled(true);
            int slot = e.getRawSlot();
            if (slot == 45) {
                int page = plugin.getPlayerCache().getPage(player.getUniqueId()) - 1;
                plugin.getGuiManager().openMainMenu(player, page);
            } else if (slot == 53) {
                int page = plugin.getPlayerCache().getPage(player.getUniqueId()) + 1;
                plugin.getGuiManager().openMainMenu(player, page);
            } else if (slot == 49) {
                player.sendMessage("§b§lFilter & Sortierung: §7Dieses Feature kommt bald!");
            } else if (slot < PAGE_SIZE) {
                List<AuctionItem> shown = plugin.getAuctionManager().getFilteredSortedAuctions();
                int index = (plugin.getPlayerCache().getPage(player.getUniqueId()) - 1) * PAGE_SIZE + slot;
                if (index < shown.size()) {
                    AuctionItem ai = shown.get(index);
                    double price = ai.getPrice();
                    boolean hasEnough = plugin.getVaultHook().getBalance(player) >= price;
                    if (!hasEnough) {
                        plugin.getGuiManager().sendAuctionInfo(player, ai, true);
                        return;
                    }
                    // Bestätigungs-GUI öffnen
                    openConfirmMenu(player, ai);
                }
            }
        } else if (e.getView().getTitle().contains("Kauf bestätigen")) {
            e.setCancelled(true);
            int slot = e.getRawSlot();
            AuctionItem ai = confirmMap.get(player.getUniqueId());
            if (ai == null) return;
            if (slot == 11) { // Kaufen
                boolean bought = plugin.getAuctionManager().buyAuction(player, ai.getAuctionId());
                if (bought) {
                    player.sendMessage(plugin.getLangManager().get("BUY_SUCCESS").replace("<item>", ai.getItem().getType().name()).replace("<price>", String.valueOf(ai.getPrice())));
                }
                player.closeInventory();
                plugin.getGuiManager().openMainMenu(player, plugin.getPlayerCache().getPage(player.getUniqueId()));
                confirmMap.remove(player.getUniqueId());
            } else if (slot == 15) { // Abbrechen
                player.closeInventory();
                confirmMap.remove(player.getUniqueId());
            }
        }
    }

    public void openConfirmMenu(Player player, AuctionItem ai) {
        Inventory inv = Bukkit.createInventory(null, 27, "§aKauf bestätigen");
        // Grünes Glas: Kaufen
        ItemStack green = new ItemStack(Material.LIME_STAINED_GLASS_PANE);
        ItemMeta greenMeta = green.getItemMeta();
        greenMeta.setDisplayName("§a§lKaufen");
        greenMeta.setLore(Arrays.asList(
            "§7Klicke, um dieses Item zu kaufen!",
            "§aPreis: §6" + ai.getPrice() + "§a$"
        ));
        green.setItemMeta(greenMeta);
        inv.setItem(11, green);
        // Item in die Mitte
        ItemStack item = ai.getItem().clone();
        if (item.getItemMeta() != null) {
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName(item.getType().name().replace('_', ' '));
            item.setItemMeta(meta);
        }
        inv.setItem(13, item);
        // Rotes Glas: Abbrechen
        ItemStack red = new ItemStack(Material.RED_STAINED_GLASS_PANE);
        ItemMeta redMeta = red.getItemMeta();
        redMeta.setDisplayName("§c§lAbbrechen");
        redMeta.setLore(Arrays.asList(
            "§7Klicke, um den Kauf abzubrechen."
        ));
        red.setItemMeta(redMeta);
        inv.setItem(15, red);
        // AuctionItem im confirmMap speichern
        confirmMap.put(player.getUniqueId(), ai);
        player.openInventory(inv);
    }

    public void sendAuctionInfo(Player player, AuctionItem ai, boolean notEnoughMoney) {
        String priceStr = String.format("%,.2f", ai.getPrice()).replace(',', '.').replace('.', ',') + " $";
        long millisLeft = ai.getEndTime() - System.currentTimeMillis();
        String timeLeft;
        if (millisLeft > 0) {
            long seconds = millisLeft / 1000;
            long hours = seconds / 3600;
            long minutes = (seconds % 3600) / 60;
            if (hours > 0) {
                timeLeft = hours + "h " + minutes + "m";
            } else {
                timeLeft = minutes + "m";
            }
        } else {
            timeLeft = "abgelaufen";
        }
        player.sendMessage("§2§lNitroSMP§7>> §7Preis: §6" + priceStr);
        player.sendMessage("§2§lNitroSMP§7>> §7Verkäufer: §b" + ai.getSellerName());
        player.sendMessage("§2§lNitroSMP§7>> §7Endet in: §e" + timeLeft);
        player.sendMessage("§2§lNitroSMP§7>> §8Auktions-ID: §7" + ai.getAuctionId().toString().substring(0, 8));
        if (notEnoughMoney) {
            player.sendMessage("§c§lDu hast nicht genug Geld für diesen Kauf!");
        }
    }
}
