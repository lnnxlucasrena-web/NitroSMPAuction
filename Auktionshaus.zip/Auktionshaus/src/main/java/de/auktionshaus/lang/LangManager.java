package de.auktionshaus.lang;

import de.auktionshaus.Main;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;

public class LangManager {
    private final Main plugin;
    private FileConfiguration messages;

    public LangManager(Main plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        messages = plugin.getFileManager().getMessages();
    }

    public String get(String key) {
        String msg = messages.getString(key);
        if (msg == null) {
            msg = ChatColor.RED + "FEHLER: " + key;
        }
        return ChatColor.translateAlternateColorCodes('&', Main.PREFIX + msg);
    }

    public String getRaw(String key) {
        return messages.getString(key, "");
    }
}
