package de.auktionshaus;

import de.auktionshaus.command.CommandManager;
import de.auktionshaus.config.FileManager;
import de.auktionshaus.economy.VaultHook;
import de.auktionshaus.lang.LangManager;
import de.auktionshaus.auction.AuctionManager;
import de.auktionshaus.database.DatabaseManager;
import de.auktionshaus.gui.GUIManager;
import de.auktionshaus.player.PlayerCache;
import de.auktionshaus.player.PlayerJoinListener;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {
    public static final String PREFIX = "§2§lNitroSMP§7>> ";
    private static Main instance;
    private VaultHook vaultHook;
    private FileManager fileManager;
    private LangManager langManager;
    private AuctionManager auctionManager;
    private DatabaseManager databaseManager;
    private GUIManager guiManager;
    private PlayerCache playerCache;
    private Plugin essentials;

    @Override
    public void onEnable() {
        instance = this;
        fileManager = new FileManager(this);
        langManager = new LangManager(this);
        vaultHook = new VaultHook(this);
        databaseManager = new DatabaseManager(this);
        auctionManager = new AuctionManager(this);
        guiManager = new GUIManager(this);
        playerCache = new PlayerCache();
        essentials = Bukkit.getPluginManager().getPlugin("Essentials");
        new CommandManager(this);
        getServer().getPluginManager().registerEvents(guiManager, this);
        getServer().getPluginManager().registerEvents(new PlayerJoinListener(), this);
        getLogger().info(PREFIX + "Plugin enabled!");
    }

    @Override
    public void onDisable() {
        if (auctionManager != null) auctionManager.saveAll();
        getLogger().info(PREFIX + "Plugin disabled!");
    }

    public static Main getInstance() { return instance; }
    public VaultHook getVaultHook() { return vaultHook; }
    public FileManager getFileManager() { return fileManager; }
    public LangManager getLangManager() { return langManager; }
    public AuctionManager getAuctionManager() { return auctionManager; }
    public DatabaseManager getDatabaseManager() { return databaseManager; }
    public GUIManager getGuiManager() { return guiManager; }
    public PlayerCache getPlayerCache() { return playerCache; }
    public Plugin getEssentials() { return essentials; }
}
