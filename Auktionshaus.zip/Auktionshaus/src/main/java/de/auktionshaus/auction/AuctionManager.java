package de.auktionshaus.auction;

import de.auktionshaus.Main;
import de.auktionshaus.util.ItemBuilder;
import de.auktionshaus.lang.LangManager;
import de.auktionshaus.economy.VaultHook;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;

public class AuctionManager {
    private final Main plugin;
    private final Map<UUID, AuctionItem> auctions = new HashMap<>();
    private final FileConfiguration auctionsYml;
    private final boolean useMySQL;
    private final double feePercent;
    private final int maxAuctionsPerPlayer;
    private final boolean allowOffline;

    private enum SortType { PRICE_ASC, PRICE_DESC, NAME, CATEGORY }
    private SortType currentSort = SortType.PRICE_ASC;
    private String currentCategory = "ALL";
    private String currentNameFilter = "";

    public AuctionManager(Main plugin) {
        this.plugin = plugin;
        FileConfiguration config = plugin.getFileManager().getConfig();
        this.auctionsYml = plugin.getFileManager().getAuctions();
        this.useMySQL = config.getString("storage.type").equalsIgnoreCase("MYSQL");
        this.feePercent = config.getDouble("auction.fee-percent");
        this.maxAuctionsPerPlayer = config.getInt("auction.max-auctions-per-player");
        this.allowOffline = config.getBoolean("auction.allow-offline");
        loadAll();
    }

    public void loadAll() {
        auctions.clear();
        if (!useMySQL) {
            if (auctionsYml.contains("auctions")) {
                for (String key : auctionsYml.getConfigurationSection("auctions").getKeys(false)) {
                    try {
                        String seller = auctionsYml.getString("auctions." + key + ".seller");
                        String sellerName = auctionsYml.getString("auctions." + key + ".sellerName");
                        String itemBase64 = auctionsYml.getString("auctions." + key + ".item");
                        double price = auctionsYml.getDouble("auctions." + key + ".price");
                        long endTime = auctionsYml.getLong("auctions." + key + ".endTime");
                        UUID auctionId = UUID.fromString(key);
                        org.bukkit.inventory.ItemStack item = de.auktionshaus.util.ItemSerializer.deserialize(itemBase64);
                        if (item == null) continue; // Fehlerhafte/alte Auktion überspringen
                        auctions.put(auctionId, new AuctionItem(UUID.fromString(seller), sellerName, item, price, endTime, auctionId));
                    } catch (Exception ignored) {}
                }
            }
        } else {
            // MySQL loading
            try {
                java.sql.Connection conn = plugin.getDatabaseManager().getConnection();
                if (conn != null) {
                    java.sql.PreparedStatement ps = conn.prepareStatement("SELECT * FROM " + plugin.getFileManager().getConfig().getString("storage.mysql.table"));
                    java.sql.ResultSet rs = ps.executeQuery();
                    while (rs.next()) {
                        UUID auctionId = UUID.fromString(rs.getString("id"));
                        UUID seller = UUID.fromString(rs.getString("seller"));
                        String sellerName = rs.getString("sellerName");
                        String itemBase64 = rs.getString("item");
                        double price = rs.getDouble("price");
                        long endTime = rs.getLong("endTime");
                        org.bukkit.inventory.ItemStack item = de.auktionshaus.util.ItemSerializer.deserialize(itemBase64);
                        auctions.put(auctionId, new AuctionItem(seller, sellerName, item, price, endTime, auctionId));
                    }
                }
            } catch (Exception ignored) {}
        }
    }

    public void saveAll() {
        if (!useMySQL) {
            auctionsYml.set("auctions", null);
            for (Map.Entry<UUID, AuctionItem> entry : auctions.entrySet()) {
                AuctionItem ai = entry.getValue();
                String path = "auctions." + ai.getAuctionId();
                auctionsYml.set(path + ".seller", ai.getSeller().toString());
                auctionsYml.set(path + ".sellerName", ai.getSellerName());
                auctionsYml.set(path + ".item", de.auktionshaus.util.ItemSerializer.serialize(ai.getItem()));
                auctionsYml.set(path + ".price", ai.getPrice());
                auctionsYml.set(path + ".endTime", ai.getEndTime());
            }
            plugin.getFileManager().saveAuctions();
        } else {
            // MySQL saving
            try {
                java.sql.Connection conn = plugin.getDatabaseManager().getConnection();
                if (conn != null) {
                    String table = plugin.getFileManager().getConfig().getString("storage.mysql.table");
                    java.sql.Statement st = conn.createStatement();
                    st.executeUpdate("DELETE FROM " + table);
                    for (AuctionItem ai : auctions.values()) {
                        java.sql.PreparedStatement ps = conn.prepareStatement("INSERT INTO " + table + " (id, seller, sellerName, item, price, endTime) VALUES (?, ?, ?, ?, ?, ?)");
                        ps.setString(1, ai.getAuctionId().toString());
                        ps.setString(2, ai.getSeller().toString());
                        ps.setString(3, ai.getSellerName());
                        ps.setString(4, de.auktionshaus.util.ItemSerializer.serialize(ai.getItem()));
                        ps.setDouble(5, ai.getPrice());
                        ps.setLong(6, ai.getEndTime());
                        ps.executeUpdate();
                    }
                }
            } catch (Exception ignored) {}
        }
    }

    public void reload() { loadAll(); }

    public void sellItem(Player player, double price) {
        if (!de.auktionshaus.util.ItemValidator.isValid(player.getInventory().getItemInMainHand())) {
            player.sendMessage(plugin.getLangManager().get("AUCTION_REMOVED"));
            return;
        }
        long duration = 24 * 60 * 60 * 1000L;
        ItemStack item = player.getInventory().getItemInMainHand().clone();
        // Name NICHT überschreiben, sondern originalen Namen/Lore beibehalten
        UUID auctionId = UUID.randomUUID();
        AuctionItem auctionItem = new AuctionItem(player.getUniqueId(), player.getName(), item, price, System.currentTimeMillis() + duration, auctionId);
        auctions.put(auctionId, auctionItem);
        player.getInventory().setItemInMainHand(null);
        saveAll();
        if (plugin.getFileManager().getConfig().getBoolean("logging.enabled")) {
            plugin.getLogger().info("[LOG] " + player.getName() + " hat ein Item für " + price + "$ eingestellt: " + item.getType().name());
        }
        // Discord Webhook Logging
        try {
            String json = "{\"embeds\":[{\"title\":\"Auktionshaus Verkauf\",\"color\":5763719,\"fields\":[{\"name\":\"Spieler\",\"value\":\"" + player.getName() + "\"},{\"name\":\"Item\",\"value\":\"" + item.getType().name().replace("_", " ") + (item.getAmount() > 1 ? " x" + item.getAmount() : "") + "\"},{\"name\":\"Preis\",\"value\":\"" + price + " $\"}]}]}";
            URL url = new URL("https://discord.com/api/webhooks/1399912726280802374/3CSosjWnM3SWeVD4AsMqgpkN-PehzSrL5h_tDSwtdWB_GyRIvIvObor72WKx5Gs0Aj75");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/json");
            con.setDoOutput(true);
            con.getOutputStream().write(json.getBytes());
            con.getOutputStream().flush();
            con.getOutputStream().close();
            con.getInputStream().close();
        } catch (Exception ignored) {}
    }

    public List<AuctionItem> getAllAuctions() {
        return new ArrayList<>(auctions.values());
    }

    public boolean buyAuction(Player buyer, UUID auctionId) {
        AuctionItem ai = auctions.get(auctionId);
        if (ai == null) {
            buyer.sendMessage(plugin.getLangManager().get("AUCTION_EXPIRED"));
            return false;
        }
        if (ai.getSeller().equals(buyer.getUniqueId())) {
            buyer.sendMessage(Main.PREFIX + "§cDu kannst deine eigenen Auktionen nicht kaufen!");
            return false;
        }
        if (System.currentTimeMillis() > ai.getEndTime()) {
            auctions.remove(auctionId);
            saveAll();
            buyer.sendMessage(plugin.getLangManager().get("AUCTION_EXPIRED"));
            return false;
        }
        double price = ai.getPrice();
        if (!plugin.getVaultHook().withdraw(buyer, price)) {
            buyer.sendMessage(Main.PREFIX + "§cDu hast nicht genug Geld.");
            return false;
        }
        ItemStack item = ai.getItem().clone();
        HashMap<Integer, ItemStack> left = buyer.getInventory().addItem(item);
        if (!left.isEmpty()) {
            plugin.getVaultHook().deposit(buyer, price);
            buyer.sendMessage(Main.PREFIX + "§cNicht genug Platz im Inventar!");
            return false;
        }
        Player seller = Bukkit.getPlayer(ai.getSeller());
        if (seller != null && seller.isOnline()) {
            plugin.getVaultHook().deposit(seller, price * (1.0 - feePercent / 100.0));
            seller.sendMessage(Main.PREFIX + "§aDein Item wurde verkauft: §b" + item.getType().name().replace('_', ' ') + (item.getAmount() > 1 ? " x" + item.getAmount() : "") + " §afür §b" + price + "§a$");
        }
        auctions.remove(auctionId);
        saveAll();
        if (plugin.getFileManager().getConfig().getBoolean("logging.enabled")) {
            plugin.getLogger().info("[LOG] " + buyer.getName() + " hat " + item.getType() + " für " + price + " von " + ai.getSellerName() + " gekauft.");
        }
        return true;
    }

    public void handleAdminCommand(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage("§cVerwendung: /ah admin <reset|force-sale <id>>");
            return;
        }
        String sub = args[1].toLowerCase();
        if (sub.equals("reset")) {
            auctions.clear();
            saveAll();
            player.sendMessage(Main.PREFIX + "§cAlle Auktionen wurden zurückgesetzt.");
            if (plugin.getFileManager().getConfig().getBoolean("logging.enabled")) {
                plugin.getLogger().info("[LOG] Alle Auktionen wurden von " + player.getName() + " zurückgesetzt.");
            }
        } else if (sub.equals("force-sale") && args.length == 3) {
            try {
                UUID auctionId = UUID.fromString(args[2]);
                auctions.remove(auctionId);
                saveAll();
                player.sendMessage(plugin.getLangManager().get("ADMIN_FORCE_SALE"));
                if (plugin.getFileManager().getConfig().getBoolean("logging.enabled")) {
                    plugin.getLogger().info("[LOG] Auktion " + auctionId + " wurde von " + player.getName() + " entfernt.");
                }
            } catch (Exception e) {
                player.sendMessage("§cUngültige Auktions-ID!");
            }
        }
    }

    public void setSortType(SortType sort) { this.currentSort = sort; }
    public void setCategory(String cat) { this.currentCategory = cat; }
    public void setNameFilter(String name) { this.currentNameFilter = name; }

    public List<AuctionItem> getFilteredSortedAuctions() {
        List<AuctionItem> list = new ArrayList<>(auctions.values());
        // Filter by category
        if (!currentCategory.equals("ALL")) {
            list.removeIf(ai -> !ai.getItem().getType().name().equalsIgnoreCase(currentCategory));
        }
        // Filter by name
        if (!currentNameFilter.isEmpty()) {
            list.removeIf(ai -> !ai.getItem().getType().name().contains(currentNameFilter.toUpperCase()));
        }
        // Sort
        switch (currentSort) {
            case PRICE_ASC -> list.sort(Comparator.comparingDouble(AuctionItem::getPrice));
            case PRICE_DESC -> list.sort(Comparator.comparingDouble(AuctionItem::getPrice).reversed());
            case NAME -> list.sort(Comparator.comparing(ai -> ai.getItem().getType().name()));
            case CATEGORY -> list.sort(Comparator.comparing(ai -> ai.getItem().getType().name()));
        }
        return list;
    }
}
