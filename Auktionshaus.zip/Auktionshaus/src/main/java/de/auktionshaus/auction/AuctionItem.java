package de.auktionshaus.auction;

import org.bukkit.inventory.ItemStack;
import java.util.UUID;

public class AuctionItem {
    private final UUID seller;
    private final String sellerName;
    private final ItemStack item;
    private final double price;
    private final long endTime;
    private final UUID auctionId;

    public AuctionItem(UUID seller, String sellerName, ItemStack item, double price, long endTime, UUID auctionId) {
        this.seller = seller;
        this.sellerName = sellerName;
        this.item = item;
        this.price = price;
        this.endTime = endTime;
        this.auctionId = auctionId;
    }
    public UUID getSeller() { return seller; }
    public String getSellerName() { return sellerName; }
    public ItemStack getItem() { return item; }
    public double getPrice() { return price; }
    public long getEndTime() { return endTime; }
    public UUID getAuctionId() { return auctionId; }
}
