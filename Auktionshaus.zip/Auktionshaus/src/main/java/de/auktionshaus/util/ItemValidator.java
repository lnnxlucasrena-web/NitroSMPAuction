package de.auktionshaus.util;

import de.auktionshaus.Main;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public class ItemValidator {
    public static boolean isValid(ItemStack item) {
        if (item == null || item.getType() == Material.AIR || item.getAmount() <= 0) return false;
        // Blacklist aus config prüfen
        List<String> blacklist = Main.getInstance().getFileManager().getConfig().getStringList("auction.blacklist");
        return !blacklist.contains(item.getType().name());
    }
}
