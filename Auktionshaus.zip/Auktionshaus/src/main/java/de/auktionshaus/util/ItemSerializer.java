package de.auktionshaus.util;

import org.bukkit.inventory.ItemStack;
import org.bukkit.configuration.serialization.ConfigurationSerialization;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
import org.bukkit.configuration.serialization.SerializableAs;
import java.util.Base64;
import java.io.*;

public class ItemSerializer {
    public static String serialize(ItemStack item) {
        try {
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            ObjectOutputStream dataOutput = new ObjectOutputStream(outputStream);
            dataOutput.writeObject(item);
            dataOutput.close();
            return Base64.getEncoder().encodeToString(outputStream.toByteArray());
        } catch (Exception e) {
            return null;
        }
    }
    public static ItemStack deserialize(String base64) {
        try {
            byte[] data = Base64.getDecoder().decode(base64);
            ObjectInputStream input = new ObjectInputStream(new ByteArrayInputStream(data));
            Object o = input.readObject();
            input.close();
            return (ItemStack) o;
        } catch (Exception e) {
            return null;
        }
    }
}
