package de.auktionshaus.command;

import de.auktionshaus.Main;
import de.auktionshaus.lang.LangManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

public class CommandManager implements CommandExecutor, TabCompleter {
    private final Main plugin;
    public CommandManager(Main plugin) {
        this.plugin = plugin;
        plugin.getCommand("ah").setExecutor(this);
        plugin.getCommand("ah").setTabCompleter(this);
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        LangManager lang = plugin.getLangManager();
        if (!(sender instanceof Player)) {
            sender.sendMessage(lang.get("NO_PERMISSION"));
            return true;
        }
        Player player = (Player) sender;
        if (args.length == 0) {
            plugin.getGuiManager().openMainMenu(player, 1);
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "sell" -> {
                if (args.length != 2) {
                    player.sendMessage(lang.get("SELL_USAGE"));
                    return true;
                }
                try {
                    double price = Double.parseDouble(args[1]);
                    plugin.getAuctionManager().sellItem(player, price);
                    String msg = "§aDein Item wurde für §b" + args[1] + "§a zum Verkauf gestellt.";
                    player.sendMessage(Main.PREFIX + msg);
                } catch (NumberFormatException e) {
                    player.sendMessage(lang.get("SELL_USAGE"));
                }
                return true;
            }
            case "pay" -> {
                if (plugin.getEssentials() == null) {
                    player.sendMessage(lang.get("PREFIX") + "§cEssentials ist nicht installiert!");
                    return true;
                }
                if (args.length != 3) {
                    player.sendMessage(lang.get("PREFIX") + "§eBenutze: /ah pay <spieler> <betrag>");
                    return true;
                }
                Player target = plugin.getServer().getPlayer(args[1]);
                if (target == null) {
                    player.sendMessage(lang.get("PREFIX") + "§cSpieler nicht gefunden!");
                    return true;
                }
                try {
                    double amount = Double.parseDouble(args[2]);
                    if (amount <= 0) {
                        player.sendMessage(lang.get("PREFIX") + "§cUngültiger Betrag!");
                        return true;
                    }
                    plugin.getVaultHook().deposit(target, amount);
                    player.sendMessage(lang.get("PREFIX") + "§aDu hast §b" + target.getName() + " §a§e" + amount + "§a$ gegeben.");
                    target.sendMessage(lang.get("PREFIX") + "§aDu hast §e" + amount + "§a$ von §b" + player.getName() + " §aerhalten.");
                } catch (NumberFormatException e) {
                    player.sendMessage(lang.get("PREFIX") + "§cUngültiger Betrag!");
                }
                return true;
            }
            case "reload" -> {
                if (!player.hasPermission("auctionshouse.admin")) {
                    player.sendMessage(lang.get("NO_PERMISSION"));
                    return true;
                }
                plugin.getFileManager().reloadAll();
                plugin.getLangManager().reload();
                plugin.getAuctionManager().reload();
                player.sendMessage(Main.PREFIX + "§3Konfiguration erfolgreich neu geladen.");
                return true;
            }
            case "admin" -> {
                if (!player.hasPermission("auctionshouse.admin")) {
                    player.sendMessage(lang.get("NO_PERMISSION"));
                    return true;
                }
                plugin.getAuctionManager().handleAdminCommand(player, args);
                return true;
            }
            case "buy" -> {
                if (args.length != 2) {
                    player.sendMessage(Main.PREFIX + "§eBenutze: /ah buy <auktions-id>");
                    return true;
                }
                try {
                    UUID auctionId = UUID.fromString(args[1]);
                    boolean bought = plugin.getAuctionManager().buyAuction(player, auctionId);
                    if (bought) {
                        player.sendMessage(Main.PREFIX + "§aKauf erfolgreich!");
                    }
                } catch (Exception e) {
                    player.sendMessage(Main.PREFIX + "§cUngültige Auktions-ID!");
                }
                return true;
            }
            default -> {
                player.sendMessage(lang.get("NO_PERMISSION"));
                return true;
            }
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("auctionshouse.use")) return Collections.emptyList();
        if (args.length == 1) {
            List<String> sub = new ArrayList<>();
            sub.add("sell");
            if (sender.hasPermission("auctionshouse.admin")) {
                sub.add("reload");
                sub.add("admin");
            }
            return sub.stream().filter(s -> s.startsWith(args[0].toLowerCase())).toList();
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("admin")) {
            return Arrays.asList("reset", "force-sale");
        }
        return Collections.emptyList();
    }
}
