package de.auktionshaus.database;

import de.auktionshaus.Main;
import org.bukkit.configuration.file.FileConfiguration;
import java.sql.*;

public class DatabaseManager {
    private final Main plugin;
    private Connection connection;
    public DatabaseManager(Main plugin) {
        this.plugin = plugin;
        setup();
    }
    public void setup() {
        FileConfiguration config = plugin.getFileManager().getConfig();
        if (config.getString("storage.type").equalsIgnoreCase("MYSQL")) {
            try {
                String host = config.getString("storage.mysql.host");
                int port = config.getInt("storage.mysql.port");
                String db = config.getString("storage.mysql.database");
                String user = config.getString("storage.mysql.user");
                String pass = config.getString("storage.mysql.password");
                String table = config.getString("storage.mysql.table");
                connection = DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/" + db, user, pass);
                Statement st = connection.createStatement();
                st.executeUpdate("CREATE TABLE IF NOT EXISTS " + table + " (id VARCHAR(36), seller VARCHAR(36), sellerName VARCHAR(32), item LONGBLOB, price DOUBLE, endTime BIGINT)");
            } catch (Exception ignored) {}
        }
    }
    public Connection getConnection() { return connection; }
}
