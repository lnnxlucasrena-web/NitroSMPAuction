package de.auktionshaus.player;

import de.auktionshaus.Main;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class PlayerJoinListener implements Listener {
    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Main.getInstance().getPlayerCache().setPage(event.getPlayer().getUniqueId(), 1);
    }
}
