package de.auktionshaus.player;

import java.util.HashMap;
import java.util.UUID;

public class PlayerCache {
    private final HashMap<UUID, Integer> pageCache = new HashMap<>();
    public int getPage(UUID uuid) { return pageCache.getOrDefault(uuid, 1); }
    public void setPage(UUID uuid, int page) { pageCache.put(uuid, page); }
}
